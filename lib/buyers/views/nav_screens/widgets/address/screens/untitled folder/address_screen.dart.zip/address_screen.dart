import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter_stripe/flutter_stripe.dart';
import 'package:fyoona/buyers/providers/user_provider.dart';
import 'package:fyoona/buyers/views/main_screen.dart';
import 'package:fyoona/buyers/views/nav_screens/widgets/address/services/address_servicess.dart';
import 'package:fyoona/buyers/views/nav_screens/widgets/custom_textfield.dart';
import 'package:fyoona/const/styles.dart';
import 'package:http/http.dart' as http;

import 'package:provider/provider.dart';

import '../../../../../../const/colors.dart';

import '../../../../../utils.dart';
import '../../custom_button.dart';

// import 'package:stripe_payment/Constants.dart';

class AddressScreen extends StatefulWidget {
  static const String routeName = '/address';

  final String totalAmount;
  const AddressScreen({super.key, required this.totalAmount});

  @override
  State<AddressScreen> createState() => _AddressScreenState();
}

class _AddressScreenState extends State<AddressScreen> {
  final TextEditingController houseBuildingController = TextEditingController();
  final TextEditingController areaController = TextEditingController();
  final TextEditingController zipcodeController = TextEditingController();
  final TextEditingController cityController = TextEditingController();

  final AddressServcies addressServcies = AddressServcies();

  final _addressFormKey = GlobalKey<FormState>();
  Map<String, dynamic>? paymentIntent;

  String addressTuse = '';
  @override
  void initState() {
    super.initState();
  }

  @override
  void dispose() {
    super.dispose();
    houseBuildingController.dispose();
    areaController.dispose();
    zipcodeController.dispose();
    cityController.dispose();
  }

  void stripePay(res) {
    if (Provider.of<UserProvider>(context, listen: false)
        .user
        .address
        .isEmpty) {
      addressServcies.saveUserAddress(context: context, address: addressTuse);
    }
    addressServcies.placeOrder(
      context,
      addressTuse,
      double.parse(
        widget.totalAmount.toString(),
      ),
    );
  }

  Future<void> makePayment() async {
    // var user = context.watch<UserProvider>().user;

    try {
      paymentIntent = await createPaymentIntent(widget.totalAmount, 'USD'
          //   , {
          //     user.fullname,
          //     user.email,
          //     user.address
          // }

          );
      //Payment Sheet
      await Stripe.instance
          .initPaymentSheet(
              paymentSheetParameters: SetupPaymentSheetParameters(
                  // customFlow: SetupPaymentSheetCustomer(id: paymentIntent!['customer']),

                  paymentIntentClientSecret: paymentIntent!['client_secret'],
                  // applePay: const PaymentSheetApplePay(merchantCountryCode: '+92',),
                  // googlePay: const PaymentSheetGooglePay(testEnv: true, currencyCode: "US", merchantCountryCode: "+92"),
                  style: ThemeMode.dark,
                  merchantDisplayName: 'Fyoona Mall'))
          .then((value) {});

      ///now finally display payment sheeet
      displayPaymentSheet();
    } catch (e, s) {
      print('exception:$e$s');
    }
  }

  // displayPaymentSheet() async {
  //   try {
  //     await Stripe.instance.presentPaymentSheet().then((value) {
  //       showDialog(
  //           context: context,
  //           builder: (_) => AlertDialog(
  //                 content: Column(
  //                   mainAxisSize: MainAxisSize.min,
  //                   children: [
  //                     Row(
  //                       children: const [
  //                         Icon(
  //                           Icons.check_circle,
  //                           color: Colors.green,
  //                         ),
  //                         InkWell(child: Text("Payment Successfull")),
  //                       ],
  //                     ),
  //                   ],
  //                 ),
  //               ));
  //       // ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("paid successfully")));

  //       paymentIntent = null;
  //     }).onError((error, stackTrace) {
  //       print('Error is:--->$error $stackTrace');
  //     });
  //   } on StripeException catch (e) {
  //     print('Error is:---> $e');
  //     showDialog(
  //         context: context,
  //         builder: (_) => const AlertDialog(
  //               content: Text("Cancelled "),
  //             ));
  //   } catch (e) {
  //     print('$e');
  //   }
  // }
  displayPaymentSheet() async {
    try {
      await Stripe.instance.presentPaymentSheet().then((value) {
        showDialog(
          context: context,
          builder: (_) => AlertDialog(
            content: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Row(
                  children: const [
                    Icon(
                      Icons.check_circle,
                      color: Colors.green,
                    ),
                    InkWell(child: Text("Payment Successful")),
                  ],
                ),
              ],
            ),
          ),
        );

        // Navigate to the PaymentSuccessScreen after successful payment
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(
            builder: (context) => const MainScreen(),
          ),
        );
        ShowSnack2(
          context,
          'Payment Successful',
        );

        // Reset paymentIntent
        paymentIntent = null;
      }).onError((error, stackTrace) {
        print('Error is:--->$error $stackTrace');
      });
    } on StripeException catch (e) {
      print('Error is:---> $e');
      showDialog(
        context: context,
        builder: (_) => const AlertDialog(
          content: Text("Cancelled "),
        ),
      );
      showSnackBar(context, 'Cancelled');
    } catch (e) {
      print('$e');
    }
  }

  createPaymentIntent(String amount, String currency) async {
    try {
      // Convert double amount to integer (cents for USD)
      int amountInCents = (double.parse(amount) * 100).round();

      Map<String, dynamic> body = {
        'amount': amountInCents.toString(),
        'currency': currency,
        'payment_method_types[]': 'card'
      };

      var response = await http.post(
        Uri.parse('https://api.stripe.com/v1/payment_intents'),
        headers: {
          'Authorization':
              'Bearer sk_test_51MTxppJI62NdnNKIzb9OdOnMXsUnQTDNl2qIGUqfrjUfu92QbqfrDu6LGFvTjyt50I814x4yag2NfG0VvWwggzCK00GmfJnlts',
          'Content-Type': 'application/x-www-form-urlencoded'
        },
        body: body,
      );

      print('Payment Intent Body->>> ${response.body.toString()}');
      return jsonDecode(response.body);
    } catch (err) {
      print('err charging user: ${err.toString()}');
    }
  }

//valdating button for address
  Future<void> payPressed(String addressFromProvider) async {
    addressTuse = '';

    bool isForm = houseBuildingController.text.isNotEmpty ||
        areaController.text.isNotEmpty ||
        zipcodeController.text.isNotEmpty ||
        cityController.text.isNotEmpty;

    if (isForm) {
      if (_addressFormKey.currentState!.validate()) {
        addressTuse =
            '${houseBuildingController.text}, ${areaController.text}, ${cityController.text} - ${zipcodeController.text}';
      } else {
        showSnackBar(context, 'Please fill all values');
        return;
      }
    } else if (addressFromProvider.isNotEmpty) {
      addressTuse = addressFromProvider;
      // Call the Stripe payment function
      // await makePayment();
    } else {
      showSnackBar(context, 'ERROR');
      return;
    }
  }

  @override
  Widget build(BuildContext context) {
    var address = context.watch<UserProvider>().user.address;

    return Scaffold(
      appBar: PreferredSize(
        preferredSize: const Size.fromHeight(60),
        child: AppBar(
          backgroundColor: Colors.yellow.shade900,
        ),
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Column(
            children: [
              if (address.isNotEmpty)
                Column(
                  children: [
                    Container(
                      width: double.infinity,
                      decoration: BoxDecoration(
                        border: Border.all(
                          color: Colors.black12,
                        ),
                      ),
                      child: Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Text(
                          address,
                          style: const TextStyle(
                            color: Colors.amber,
                            fontSize: 18,
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(height: 20),
                    const Text(
                      'OR',
                      style: TextStyle(
                        fontSize: 18,
                      ),
                    ),
                    const SizedBox(height: 20),
                  ],
                ),
              Form(
                key: _addressFormKey,
                child: Column(
                  children: [
                    CustomTextField(
                      controller: houseBuildingController,
                      hintText: 'House No, Building ',
                    ),
                    const SizedBox(
                      height: 10,
                    ),
                    CustomTextField(
                      controller: areaController,
                      hintText: 'Area, Street',
                    ),
                    const SizedBox(
                      height: 10,
                    ),
                    CustomTextField(
                      controller: zipcodeController,
                      hintText: 'ZipCode',
                    ),
                    const SizedBox(
                      height: 10,
                    ),
                    CustomTextField(
                      // obscureText: true,
                      controller: cityController,
                      hintText: 'City/Town ',
                    ),
                    const SizedBox(
                      height: 10,
                    ),
                  ],
                ),
              ),
              const SizedBox(
                height: 10,
              ),
              const SizedBox(
                height: 10,
              ),
              CustomButton(
                text: 'Check Out',

                // ignore: avoid_returning_null_for_void
                onTap: () async {
                  // await payPressed();
                  await makePayment();

                  print('Make payment button cliked');
                },
                color: yellowcolor,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
