import 'package:flutter/material.dart';
import 'package:fyoona/buyers/providers/user_provider.dart';
import 'package:fyoona/const/colors.dart';

import 'package:provider/provider.dart';

import 'buyers/views/auth/user_login.dart';
import 'buyers/views/main_screen.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  changeScreen() async {
    await Future.delayed(const Duration(seconds: 1));

    // ignore: use_build_context_synchronously
    final userProvider = Provider.of<UserProvider>(context, listen: false);

    // Check if the user is logged in based on the presence of the access token
    if (userProvider.user.token.isNotEmpty) {
      // ignore: use_build_context_synchronously
      Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) {
        return const MainScreen();
      }));
    } else {
      // ignore: use_build_context_synchronously
      Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) {
        return const BuyersLoginScreen();
      }));
    }
  }

  @override
  void initState() {
    changeScreen();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: yellowcolor,
    );
  }
}
