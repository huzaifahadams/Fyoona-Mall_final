import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:fyoona/vendors/providers/vendor_provider.dart';
import 'package:http/http.dart' as http;
import 'package:provider/provider.dart';

import '../../../buyers/error_handling.dart';
import '../../../buyers/utils.dart';
import '../../../global_variables.dart';
import '../../models/product.dart';

class ProductsServcies {
  sellProduct({
    required BuildContext context,
    required String productName,
    required String productDescription,
    required double productPrice,
    required int quantity,
    required String category,
    List<String>? imageUrList, // Change the type to List<String>

    String? mediaUrl,
    required String brandName,
    required DateTime scheduleDate,
    required String videoUrl,
    double? shippingFee,
    List<String>? sizeList,
    List<String>? colorList,
    required String vendorId,
    required chargeShipping,
  }) async {
    final userProvider = Provider.of<VendorProvider>(context, listen: false);
    try {
      Product product = Product(
        productName: productName,
        productDescription: productDescription,
        quantity: quantity,
        imageUrList: imageUrList ?? [], // Provide a default value for null case
        videoUrl: mediaUrl ?? videoUrl,
        category: category,
        productPrice: productPrice,
        shippingFee: shippingFee,
        scheduleDate: scheduleDate,
        chargeShipping: chargeShipping,
        brandName: brandName,
        sizeList: sizeList,
        colorList: colorList,
        vendorId: vendorId,
      );
      http.Response res = await http.post(
        Uri.parse('$uri/api/products/add-product'),
        headers: <String, String>{
          'Content-Type': 'application/json; charset=UTF-8',
          'x-auth-token': userProvider.user.token,
        },
        body: product.toJson(),
      );

      // ignore: use_build_context_synchronously
      httpErrorHandle(
        response: res,
        context: context,
        onSuccess: () {
          showSnackBar(context, 'Product Added Successfully');
          Navigator.pop(context);
        },
      );
    } on SocketException {
      showSnackBar(context, "Please check your internet connection.");
    } on TimeoutException {
      showSnackBar(context, "The request timed out. Please try again later.");
    } catch (e, stackTrace) {
      showSnackBar(context,
          "An error occurred while uploading product: ${e.toString()} \n Line number: ${stackTrace.toString().split('\n')[1]}");
    }
  }
}

// get products

Future<List<Product>> fetchAllProducts(BuildContext context) async {
  final userProvider = Provider.of<VendorProvider>(context, listen: false);
  List<Product> productList = [];
  try {
    http.Response res =
        await http.get(Uri.parse('$uri/api/products/get-products'), headers: {
      'Content-Type': 'application/json; charset-UTF-8',
      'x-auth-token': userProvider.user.token,
    });
    // ignore: use_build_context_synchronously
    httpErrorHandle(
      response: res,
      context: context,
      onSuccess: () {
        for (int i = 0; i < jsonDecode(res.body).length; i++) {
          productList.add(
            Product.fromJson(
              jsonEncode(jsonDecode(res.body)[i]),
            ),
          );
        }
      },
    );
  } on SocketException {
    showSnackBar(context, "Please check your internet connection.");
  } on TimeoutException {
    showSnackBar(context, "The request timed out. Please try again later.");
  } catch (e, stackTrace) {
    showSnackBar(context,
        "An error occurred while fetching products: ${e.toString()} \n Line number: ${stackTrace.toString().split('\n')[1]}");

    // "An error occurred while fetching products: ${e.toString()}");
  }
  return productList;
}

//delete product
delteProduct({
  required BuildContext context,
  required Product product,
  required VoidCallback onSuccess,
}) async {
  final userProvider = Provider.of<VendorProvider>(context, listen: false);
  try {
    http.Response res = await http.post(
      Uri.parse('$uri/api/products/del-product'),
      headers: <String, String>{
        'Content-Type': 'application/json; charset=UTF-8',
        'x-auth-token': userProvider.user.token,
      },
      body: jsonEncode({
        'id': product.id,
      }),
    );

    // ignore: use_build_context_synchronously
    httpErrorHandle(
      response: res,
      context: context,
      onSuccess: () {
        onSuccess();
      },
    );
  } on SocketException {
    showSnackBar(context, "Please check your internet connection.");
  } on TimeoutException {
    showSnackBar(context, "The request timed out. Please try again later.");
  } catch (e, stackTrace) {
    showSnackBar(context,
        "An error occurred while deleting products: ${e.toString()} \n Line number: ${stackTrace.toString().split('\n')[1]}");

    // "An error occurred while fetching products: ${e.toString()}");
  }
}

Future<void> updateProduct({
  required BuildContext context,
  required String id,
  required Map<String, dynamic> updatedData,
}) async {
  final userProvider = Provider.of<VendorProvider>(context, listen: false);
  try {
    http.Response res = await http.post(
      Uri.parse('$uri/api/products/update-product/$id'),
      headers: <String, String>{
        'Content-Type': 'application/json; charset=UTF-8',
        'x-auth-token': userProvider.user.token,
      },
      body: jsonEncode(updatedData),
    );

    httpErrorHandle(
      response: res,
      context: context,
      onSuccess: () {
        // Handle success if needed
      },
    );
  } on SocketException {
    showSnackBar(context, "Please check your internet connection.");
  } on TimeoutException {
    showSnackBar(context, "The request timed out. Please try again later.");
  } catch (e, stackTrace) {
    showSnackBar(context,
        "An error occurred while updating the product: ${e.toString()} \n Line number: ${stackTrace.toString().split('\n')[1]}");
  }
}


  // //get all orders
  // Future<List<Order>> fetchAllOrders(BuildContext context) async {
  //   final userProvider = Provider.of<UserProvider>(context, listen: false);
  //   List<Order> orderList = [];
  //   try {
  //     http.Response res =
  //         await http.get(Uri.parse('$uri/admin/get-allproducts'), headers: {
  //       'Content-Type': 'application/json; charset-UTF-8',
  //       'x-auth-token': userProvider.user.token,
  //     });
  //     // ignore: use_build_context_synchronously
  //     httpErrorHandle(
  //       response: res,
  //       context: context,
  //       onSuccess: () {
  //         for (int i = 0; i < jsonDecode(res.body).length; i++) {
  //           orderList.add(
  //             Order.fromJson(
  //               jsonEncode(jsonDecode(res.body)[i]),
  //             ),
  //           );
  //         }
  //       },
  //     );
  //   } on SocketException {
  //     showSnackBar(context, "Please check your internet connection.");
  //   } on TimeoutException {
  //     showSnackBar(context, "The request timed out. Please try again later.");
  //   } catch (e, stackTrace) {
  //     showSnackBar(context,
  //         "An error occurred while fetching products: ${e.toString()} \n Line number: ${stackTrace.toString().split('\n')[1]}");

  //     // "An error occurred while fetching products: ${e.toString()}");
  //   }
  //   return orderList;
  // }

  // buttons to change order status

  // void changeOrderStatus({
  //   required BuildContext context,
  //   required int status,
  //   required Order order,
  //   required VoidCallback onSuccess,
  // }) async {
  //   final userProvider = Provider.of<UserProvider>(context, listen: false);
  //   try {
  //     http.Response res = await http.post(
  //       Uri.parse('$uri/admin/change-order-status'),
  //       headers: <String, String>{
  //         'Content-Type': 'application/json; charset=UTF-8',
  //         'x-auth-token': userProvider.user.token,
  //       },
  //       body: jsonEncode({
  //         'id': order.id,
  //         'status': status,
  //       }),
  //     );

  //     // ignore: use_build_context_synchronously
  //     httpErrorHandle(
  //       response: res,
  //       context: context,
  //       onSuccess: onSuccess,
  //     );
  //   } on SocketException {
  //     showSnackBar(context, "Please check your internet connection.");
  //   } on TimeoutException {
  //     showSnackBar(context, "The request timed out. Please try again later.");
  //   } catch (e, stackTrace) {
  //     showSnackBar(context,
  //         "An error occurred while deleting products: ${e.toString()} \n Line number: ${stackTrace.toString().split('\n')[1]}");

  //     // "An error occurred while fetching products: ${e.toString()}");
  //   }
  // }

  //get total amounts of earnings with cate

  // Future<Map<String, dynamic>> getEarnings(BuildContext context) async {
  //   final userProvider = Provider.of<UserProvider>(context, listen: false);
  //   List<Sales> sales = [];
  //   int totalEarning = 0;
  //   try {
  //     http.Response res =
  //         await http.get(Uri.parse('$uri/admin/analytics'), headers: {
  //       'Content-Type': 'application/json; charset-UTF-8',
  //       'x-auth-token': userProvider.user.token,
  //     });
  //     // ignore: use_build_context_synchronously
  //     httpErrorHandle(
  //       response: res,
  //       context: context,
  //       onSuccess: () {
  //         var response = jsonDecode(res.body);
  //         totalEarning = response['totalEarnings'];
  //         sales = [
  //           Sales('Mobiles', response['mobileEarnings']),
  //           Sales('Essentials', response['essentialEarnings']),
  //           Sales('Appliances', response['appliancesEarnings']),
  //           Sales('Books', response['booksEarnings']),
  //           Sales('Fashion', response['fashionEarnings']),
  //         ];
  //       },
  //     );
  //   } on SocketException {
  //     showSnackBar(context, "Please check your internet connection.");
  //   } on TimeoutException {
  //     showSnackBar(context, "The request timed out. Please try again later.");
  //   } catch (e, stackTrace) {
  //     showSnackBar(context,
  //         "An error occurred while fetching products: ${e.toString()} \n Line number: ${stackTrace.toString().split('\n')[1]}");

  //     // "An error occurred while fetching products: ${e.toString()}");
  //   }
  //   return {
  //     'sales': sales,
  //     'totalEarnings': totalEarning,
  //   };
  // }
//}

//   Future<Map<String, dynamic>> getEarnings(BuildContext context) async {
//     final userProvider = Provider.of<UserProvider>(context, listen: false);
//     List<Sales> sales = [];
//     int totalEarning = 0;
//     try {
//       http.Response res =
//           await http.get(Uri.parse('$uri/admin/analytics'), headers: {
//         'Content-Type': 'application/json; charset=UTF-8',
//         'x-auth-token': userProvider.user.token,
//       });

//       // ignore: use_build_context_synchronously
//       httpErrorHandle(
//         response: res,
//         context: context,
//         onSuccess: () {
//           var response = jsonDecode(res.body);
//           totalEarning = response['totalEarnings'];
//           sales = [
//             Sales('Mobiles', response['mobileEarnings']),
//             Sales('Essentials', response['essentialEarnings']),
//             Sales('Books', response['booksEarnings']),
//             Sales('Appliances', response['applianceEarnings']),
//             Sales('Fashion', response['fashionEarnings']),
//           ];
//         },
//       );
//     } catch (e) {
//       showSnackBar(context, e.toString());
//     }
//     return {
//       'sales': sales,
//       'totalEarnings': totalEarning,
//     };
//   }
// }

//   Future<List<Product>> fetchAllProducts(BuildContext context) async {
//     final userProvider = Provider.of<UserProvider>(context, listen: false);
//     List<Product> productList = [];
//     try {
//       http.Response res =
//           await http.get(Uri.parse('$uri/admin/get-products'), headers: {
//         'Content-Type': 'application/json; charset-UTF-8',
//         'x-auth-token': userProvider.user.token,
//       });
//       httpErrorHandle(
//         response: res,
//         context: context,
//         onSuccess: () {
//           for (int i = 0; i < jsonDecode(res.body).length; i++) {
//             productList.add(
//               Product.fromJson(
//                 jsonEncode(
//                   jsonDecode(res.body)[i],
//                 ),
//               ),
//             );
//           }
//         },
//       );
//     } catch (e) {
//       showSnackBar(context, e.toString());
//     }
//     return productList;
//   }
// }

